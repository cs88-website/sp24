######################
#### Trees ####
######################
# Tree Class
class Tree:
    def __init__(self, value, branches=()):
        self.value = value
        for branch in branches:
            assert isinstance(branch, Tree)
        self.branches = list(branches)

    def __repr__(self):
        if self.branches:
            branches_str = ', ' + repr(self.branches)
        else:
            branches_str = ''
        return 'Tree({0}{1})'.format(self.value, branches_str)

    def __str__(self):
        def print_tree(t, indent=0):
            tree_str = '  ' * indent + str(t.value) + "\n"
            for b in t.branches:
                tree_str += print_tree(b, indent + 1)
            return tree_str
        return print_tree(self).rstrip()

    def is_leaf(self):
        return not self.branches



def same_shape(t1, t2):
    """Returns whether two Trees t1, t2 have the same shape. Two trees have the
    same shape if they have the same number of branches and each of their
    children have the same shape.

    >>> t, s = Tree(1), Tree(3)
    >>> same_shape(t, t)
    True
    >>> same_shape(t, s)
    True
    >>> t = Tree(1, [Tree(2), Tree(3)])
    >>> same_shape(t, s)
    False
    >>> s = Tree(4, [Tree(7)])
    >>> same_shape(t, s)
    False
    >>> s.branches.append(Tree(6)) # Add a new leaf to s to make it same shape as t
    >>> same_shape(t, s)
    True
    """
    "*** YOUR CODE HERE ***"


def cumulative_sum(t):
    """Return a new Tree, where each value is the sum of all values in the
    corresponding subtree of t.

    >>> t = Tree(1, [Tree(3, [Tree(5)]), Tree(7)])
    >>> cumulative = cumulative_sum(t)
    >>> t
    Tree(1, [Tree(3, [Tree(5)]), Tree(7)])
    >>> cumulative
    Tree(16, [Tree(8, [Tree(5)]), Tree(7)])
    >>> cumulative_sum(Tree(1))
    Tree(1)
    """
    "*** YOUR CODE HERE ***"


def find_level(t, level):
    """
    >>> t = Tree(1, [Tree(2, [Tree(4), Tree(5)]), Tree(6, [Tree(7)])])
    >>> find_level(t, 2)
    [4, 5, 7]
    >>> find_level(t, 1)
    [2, 6]
    >>> find_level(t, 5)
    []
    """
    "*** YOUR CODE HERE ***"



def merge_trees(t1, t2, fn):
    """
    >>> one = Tree(1, [Tree(2, [Tree(4), Tree(5)]), Tree(6)])
    >>> two = Tree(11, [Tree(10, [Tree(10), Tree(10)]), Tree(10)])
    >>> merge_trees(one, two, lambda x, y: x + y)
    Tree(12, [Tree(12, [Tree(14), Tree(15)]), Tree(16)])
    >>> merge_trees(one, two, lambda x, y: y - x)
    Tree(10, [Tree(8, [Tree(6), Tree(5)]), Tree(4)])
    """
    "*** YOUR CODE HERE ***"


def quiet_get(data, selector, missing=None):
    """Return data[selector] if it exists, otherwise return missing.

    >>> quiet_get([1, 2, 3], 1)
    2
    >>> quiet_get([1, 2, 3], 4) # no missing argument passed in, so returns None
    >>> quiet_get([1, 2, 3], 4, -1)
    -1
    >>> quiet_get({'a': 2, 'b': 5}, 'a', -1)
    2
    >>> quiet_get({'a': 2, 'b': 5}, 'd', -1)
    -1
    """
    "*** YOUR CODE HERE ***"

